import { Component } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { FormGroup, FormControl } from '@angular/forms'
@Component({
  selector: 'app-shop',
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    AppRouterModule
  ],
  templateUrl: './shop.html',
  styleUrl: './shop.css',

})
export class Shop {
  question = "What is your Name?";
  answer = "unkown";
  appForm = new FormGroup({
    answer: new FormControl('')
  });

}
