import { Component } from '@angular/core';
import { constructor } from 'assert';
import { Component, OnInit, Input } from '@angular/core';
@Input() name: string;

@Component({
  selector: 'app-info',
  imports: [],
  templateUrl: './info.html',
  styleUrl: './info.css',
})
export class Info implement OnInit
{
  @Input() name: string;
  quantaty = 0;
  products: string[] = [];
  selectedProduct = "Star Wars";
}
constructor() {
  ngOnInit(){
    this.quantaty = 0;
    this.products = ["Star Wars", "Star Trek", "The Matrix", "Inception"];
    this.selectedProduct = "Star Wars";
  }
}
